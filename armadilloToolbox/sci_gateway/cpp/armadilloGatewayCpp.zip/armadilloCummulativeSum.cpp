// Gateway to Aramdillo function cumsum -  cumulative sum of elements in each column or cumulative sum of elements in each row

#include "armaMat.h"
extern "C"
{
#include "api_scilab.h"
#include "Scierror.h"
#include "BOOL.h"
#include <localization.h>

    static const char fname[] = "cummulativeSum"; //Function name for scilab interface

    int armadilloCummulativeSum(scilabEnv env, int nin, scilabVar *in, int nopt, scilabOpt *opt, int nout, scilabVar *out)
    {
        int row = 0;
        int column = 0;
        int size = 0;
        double *inputArray = NULL;
        double dimension = 0;

        // Check input argument count
        if (nin != 2)
        {
            Scierror(77, _("%s: Wrong number of input argument(s): %d expected.\n"), fname, 2);
            return 1;
        }
        // Check first argument type for array
        if (scilab_isMatrix2d(env, in[0]) != 1)
        {
            Scierror(999, _("%s: Wrong type for input argument #%d: An array expected.\n"), fname, 1);
            return 1;
        }
        // Check second argument type for double
        if (scilab_isDouble(env, in[1]) == 0 || scilab_isScalar(env, in[1]) == 0)
        {
            Scierror(999, _("%s: Wrong type for input argument #%d: A scalar expected.\n"), fname, 2);
            return 1;
        }
        // Get dimensions of input array
        size = scilab_getDim2d(env, in[0], &row, &column);

        // Check for 0 in row/column
        if (row == 0 || column == 0)
        {
            Scierror(77, _("%s: Size(s) cannot be 0 minimum: %d expected.\n"), fname, 1);
            return 1;
        }

        // Copy input array and dimension
        scilab_getDoubleArray(env, in[0], &inputArray);
        scilab_getDouble(env, in[1], &dimension);

        // Dimension check for row or column
        if (dimension != 1 && dimension != 0)
        {
            Scierror(77, _("%s: Dimension cannot be: %.0lf, 0 for cumulative sum of elements in each column and 1 for cumulative sum of elements in each row.\n"), fname, dimension);
            return 1;
        }

        vector<vector<double>> inputMat(row, vector<double>(column));

        int k = 0;
        for (int i = 0; i < row; i++)
            for (int j = 0; j < column; j++)
                inputMat[i][j] = inputArray[k++];

        // Call source armadillo function
        vector<vector<double>> outputMat = cummulativeSum(inputMat, dimension);

        double *m = (double *)malloc(sizeof(double) * row * column);

        // Setting output format for scilab
        out[0] = scilab_createDoubleMatrix2d(env, row, column, 0);

        scilab_getDoubleArray(env, out[0], &m);

        // Return output to scilab
        for (int i = 0; i < outputMat.size(); i++)
        {
            for (int j = 0; j < outputMat[0].size(); j++)
            {
                m[i + outputMat.size() * j] = outputMat[i][j];
            }
        }
        return 0;
    }
}
