// Gateway to Aramdillo function randu - to genearte 2d array with random values of range[0,1]

#include "armaMat.h"
extern "C"
{
#include <Scierror.h>
#include <api_scilab.h>
#include <stdio.h>
#include "localization.h"

	static const char fname[] = "genRand2d01"; //Function name for scilab interface
	int armadilloGenRand2d(scilabEnv env, int nin, scilabVar *in, int nopt, scilabOpt *opt, int nout, scilabVar *out)

	{
		// To store row and column values from scilab
		double row = 1, column = 1;

		// To check number of input arguments
		if (nin != 2)
		{
			Scierror(77, _("%s: Wrong number of input argument(s): %d expected.\n"), fname, 2);
			return 1;
		}

		// Check input type
		if (scilab_isDouble(env, in[1]) != 1 || scilab_isDouble(env, in[0]) != 1)
		{
			Scierror(999, _("%s: Wrong type for input argument: integer is expected.\n"), fname);
			return 1;
		}

		// Copy input values to row and column variables
		scilab_getDouble(env, in[0], &row);
		scilab_getDouble(env, in[1], &column);

		// Validate input - 0 check for row and column
		if (row == 0 || column == 0)
		{
			Scierror(77, _("%s: Size(s) cannot be 0 minimum: %d expected.\n"), fname, 1);
			return 1;
		}

		// Call source armadillo function
		vector<vector<double>> out1 = randMat01(row, column);

		double *output2D = (double *)malloc(sizeof(double) * row * column);

		// Setting up the output format for scilab
		out[0] = scilab_createDoubleMatrix2d(env, row, column, 0);
		scilab_getDoubleArray(env, out[0], &output2D);

		// Return value to scilab
		for (int i = 0; i < out1.size(); i++)
		{
			for (int j = 0; j < out1[0].size(); j++)
			{
				output2D[i + out1.size() * j] = out1[i][j];
			}
		}
		return 0;
	}
}
