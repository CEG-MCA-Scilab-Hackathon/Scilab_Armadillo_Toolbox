// Gateway to Aramdillo function accu - accumulates the array value(Sum of all elements)

#include "armaMat.h"
extern "C"
{
#include "api_scilab.h"
#include "Scierror.h"
#include "BOOL.h"
#include <localization.h>

    static const char fname[] = "accumulate"; //Function name for scilab interface

    int armadilloAccumulate(scilabEnv env, int nin, scilabVar *in, int nopt, scilabOpt *opt, int nout, scilabVar *out)
    {
        int row = 0;
        int column = 0;
        int size = 0;
        double *inputArray = NULL;

        // Check input argument count
        if (nin != 1)
        {
            Scierror(77, _("%s: Wrong number of input argument(s): %d expected.\n"), fname, 1);
            return 1;
        }
        // Check argument type
        if (scilab_isMatrix2d(env, in[0]) != 1)
        {
            Scierror(999, _("%s: Wrong type for input argument #%d: A scalar expected.\n"), fname, 1);
            return 1;
        }
        // Get array dimensions
        size = scilab_getDim2d(env, in[0], &row, &column);
        if (row == 0 || column == 0)
        {
            Scierror(77, _("%s: Size(s) cannot be 0 minimum: %d expected.\n"), fname, 1);
            return 1;
        }
        // Copy input array
        scilab_getDoubleArray(env, in[0], &inputArray);

        vector<vector<double>> inputMat(row, vector<double>(column));

        int k = 0;
        for (int i = 0; i < row; i++)
            for (int j = 0; j < column; j++)
                inputMat[i][j] = inputArray[k++];
        // Calling armadillo function source and passing the output to scilab
        out[0] = scilab_createDouble(env, accumulate(inputMat));

        return 0;
    }
}